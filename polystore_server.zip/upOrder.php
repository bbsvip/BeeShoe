<?php

$servername = "localhost";
$username = "id11782388_mrbbs";
$password = "0331999@@@";
$dbname = "id11782388_beeshoe";

$user = $_POST['user'];
$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];
$user_phone = $_POST['user_phone'];
$user_address = $_POST['user_address'];
$name_sp = $_POST['name_sp'];
$img = $_POST['img'];
$gia_sp = $_POST['gia_sp'];
$sl_sp = $_POST['sl_sp'];

try {

    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // set the PDO error mode to exception

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO pay (user, user_name, user_phone, user_email, user_address, name_sp, img, gia_sp, sl_sp) 
    VALUES ('".$_POST['user']."', '".$_POST['user_name']."', '".$_POST['user_phone']."', '".$_POST['user_email']."','".$_POST['user_address']."',
    '".$_POST['name_sp']."','".$_POST['img']."','".$_POST['gia_sp']."','".$_POST['sl_sp']."')";

    // use exec() because no results are returned

    $conn->exec($sql);

    echo "success";

    }

catch(PDOException $e)

    {

    echo $sql . "<br>" . $e->getMessage();

    }



$conn = null;

?>