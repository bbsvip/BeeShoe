<html>

<head>

    <title>Xem tất cả sản phẩm</title>
    <meta charset="utf-8">
    <style>
        table tr td {
            border-bottom: 2px solid #ccc;
            padding-left: 15px;
            padding-right: 15px;
        }
    </style>
</head>

<body>



    <h2>Xem tất cả sản phẩm</h2>
    
    <?php
        $database = "id11782388_beeshoe";
        $username = "id11782388_mrbbs";
        $password = "0331999@@@";
        $connect = mysqli_connect($server,$username,$password,$database);
        mysqli_query($connect,"SET NAMES 'utf8'");
        if (!$connect) {
            die("Connection failed: " . mysqli_connect_error());
        } else {
        //echo "connection successful";
        }

        // query students table
        $sql = 'SELECT * FROM `sp`';

        $result = mysqli_query($connect, $sql);

        if (!$result) {
            die('Query error: ['.$db -> error. ']');
        }

        echo mysqli_num_rows($result)." sản phẩm";

        

    ?>
    <a href="./get.php">Đăng sản phẩm</a>
    <table>
        <thead>
            <tr>
                <th>Mã sản phẩm</th>
                <th>Tên sản phẩm</th>
                <th>Ảnh xem trước</th>
                <th>Tất cả ảnh</th>
                <th>Thông tin sản phẩm</th>
                <th>Tất cả kích thước</th>
                <th>Màu sắc</th>
                <th>Giá sản phẩm</th>
                <th>Số lượng</th>
                <th>Giới tính</th>
                <th>Loại sản phẩm</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) : ?>
                    <tr>
                        <td><?php echo $row['id_sp']; ?>
            </td>
            <td>
                <?php echo $row['name_sp']; ?>
            </td>
            <td>
                <img src="<?php echo $row['pic_sp']; ?>" alt="ảnh xem trước" width="100px"/>
                
            </td>
            <td>
                <?php echo $row['pics_sp']; ?>
            </td>
            <td>
                <?php echo $row['info_sp']; ?>
            </td>
            <td>
                <?php echo $row['size_sp']; ?>
            </td>
            <td>
                <?php echo $row['color_sp']; ?>
            </td>
            <td>
                <?php echo $row['gia_sp']; ?>
            </td>
            <td>
                <?php echo $row['sl_sp']; ?>
            </td>
            <td>
                <?php echo $row['sex_sp']; ?>
            </td>
            <td>
                <?php echo $row['type']; ?>
            </td>

            </tr>
            <?php endwhile;  ?>
        </tbody>
    </table>
</body>

</html>