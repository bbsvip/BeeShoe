<?php
$servername = "localhost";
$username = "id11782388_mrbbs";
$password = "0331999@@@";
$dbname = "id11782388_beeshoe";

$user = $_POST['user'];
$pass = $_POST['pass'];
$user_name = $_POST['user_name'];
$user_email = $_POST['user_email'];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO acc (user, pass, user_name, user_email) VALUES ('".$_POST['user']."', '".$_POST['pass']."', '".$_POST['user_name']."', '".$_POST['user_email']."')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "success";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>