<?php
        	$servername = "localhost";
$username = "id11782388_mrbbs";
$password = "0331999@@@";
$dbname = "id11782388_beeshoe";

        $name_sp = "";
        $pic_sp = "";
        $pics_sp = "";
        $info_sp = "";
        $size_sp = "";
        $color_sp = "";
        $gia_sp = "";
        $sl_sp = "";
        $sex_sp = "";
        $type = "";
        
        try {
            //Lấy giá trị POST từ form vừa submit
        if(isset($_POST["name_sp"])) { $name_sp = $_POST['name_sp']; }
		if(isset($_POST["pic_sp"])) { $pic_sp = $_POST['pic_sp']; }
		if(isset($_POST["pics_sp"])) { $pics_sp = $_POST['pics_sp']; }
		if(isset($_POST["info_sp"])) { $info_sp = $_POST['info_sp']; }
		if(isset($_POST["size_sp"])) { $size_sp = $_POST['size_sp']; }
		if(isset($_POST["color_sp"])) { $color_sp = $_POST['color_sp']; }
		if(isset($_POST["gia_sp"])) { $gia_sp = $_POST['gia_sp']; }
		if(isset($_POST["sl_sp"])) { $sl_sp = $_POST['sl_sp']; }
		if(isset($_POST["sex_sp"])) { $sex_sp = $_POST['sex_sp']; }
		if(isset($_POST["type"])) { $type = $_POST['type']; }
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO sp (name_sp, pic_sp, pics_sp, info_sp, size_sp, color_sp, gia_sp, sl_sp, sex_sp,type)
		VALUES ('$name_sp', '$pic_sp', '$pics_sp', '$info_sp', '$size_sp', '$color_sp', '$gia_sp', '$sl_sp', '$sex_sp', '$type')";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "success";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
        
		
?>