<?php



require "connect.php";



	$query = "SELECT * FROM `pay`";

	$data = mysqli_query($connect, $query);

	class getPay{

		function getPay($id_order, $user, $user_name,$user_email, $user_phone, $user_address, $name_sp, $img, $gia_sp, $sl_sp, $date_order){

			$this->id_order = $id_order;

            $this->user = $user;

            $this->name = $user_name;

            $this->email = $user_email;

            $this->user_phone = $user_phone;

            $this->user_address = $user_address;

            $this->name_sp = $name_sp;

            $this->img = $img;
            $this->gia_sp = $gia_sp;
            $this->sl_sp = $sl_sp;
            $this->date_order = $date_order;

		}

		

	}

	$array = array();

	while ($row = mysqli_fetch_assoc($data)) {

		array_push($array, new getPay($row['id_order'], $row['user'], $row['name'],$row['email'], $row['user_phone'],

														$row['user_address'], $row['name_sp'], $row['img'], $row['gia_sp'],$row['sl_sp'],$row['date_order']));

	}

	echo  json_encode($array);



?>