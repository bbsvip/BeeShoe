<?php

require 'connect.php';


$query = "SELECT * FROM sp";
$data = mysqli_query($connect,$query);

//tạo class
class SP{
	function SP($id_sp, $name_sp, $pic_sp, $pics_sp, $info_sp, $size_sp, $color_sp, $count_click, $gia_sp, $sl_sp, $sex_sp, $type, $rate){
		$this->id_sp = $id_sp;
        $this->name_sp = $name_sp;
        $this->pic_sp = $pic_sp;
        $this->pics_sp = $pics_sp;
        $this->info_sp = $info_sp;
        $this->size_sp = $size_sp;
        $this->color_sp = $color_sp;
        $this->count_click = $count_click;
        $this->gia_sp = $gia_sp;
        $this->sl_sp = $sl_sp;
        $this->sex_sp = $sex_sp;
        $this->type = $type;
        $this->rate = $rate;
	}
}
//mảng
$mangSP = array();
//add
while ($row = mysqli_fetch_assoc($data)) {
	array_push($mangSP, new SP($row['id_sp'],$row['name_sp'],$row['pic_sp'],$row['pics_sp'],$row['info_sp'],$row['size_sp'],$row['color_sp'],$row['count_click'],$row['gia_sp'],$row['sl_sp'],$row['sex_sp'],$row['type'],$row['rate']));
}
//chuyển mảng sang json
echo json_encode($mangSP);



?>