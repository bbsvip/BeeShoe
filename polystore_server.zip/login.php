<?php

require "connect.php";

	$query = "SELECT * FROM `acc`";
	$data = mysqli_query($connect, $query);
	class checkLogin{
		function checkLogin($id_acc, $user, $pass,$user_name, $user_email, $user_date, $user_address, $user_favor){
			$this->id_acc = $id_acc;
            $this->user = $user;
            $this->pass = $pass;
            $this->name = $user_name;
            $this->email = $user_email;
            $this->user_date = $user_date;
            $this->user_address = $user_address;
            $this->user_favor = $user_favor;
		}
		
	}
	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		array_push($array, new checkLogin($row['id_acc'], $row['user'], $row['pass'],$row['user_name'], $row['user_email'],
														$row['user_date'], $row['user_address'], $row['user_favor']));
	}
	echo  json_encode($array);

?>