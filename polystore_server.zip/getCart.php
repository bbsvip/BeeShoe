<?php

require "connect.php";

	$query = "SELECT * FROM `cart`";
	$data = mysqli_query($connect, $query);
	class checkLogin{
		function checkLogin($id_cart, $id_acc, $id_sp,$sl_cart){
			$this->id_acc = $id_acc;
            $this->id_acc = $id_acc;
            $this->id_sp = $id_sp;
            $this->sl_cart = $sl_cart;
		}
		
	}
	$array = array();
	while ($row = mysqli_fetch_assoc($data)) {
		array_push($array, new checkLogin($row['id_cart'], $row['id_acc'], $row['id_sp'],$row['id_cart']));
	}
	echo  json_encode($array);

?>