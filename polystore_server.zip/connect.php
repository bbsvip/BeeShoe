<?php
        $server = "localhost";
        $database = "id11782388_beeshoe";
        $username = "id11782388_mrbbs";
        $password = "0331999@@@";
        $connect = mysqli_connect($server,$username,$password,$database);
        mysqli_query($connect,"SET NAMES 'utf8'");
        if (!$connect) {
            die("Connection failed: " . mysqli_connect_error());
        } else {
        //echo "connection successful";
        }
        ?>