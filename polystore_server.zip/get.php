<html>

<head>
    <title>Đăng thông tin sản phẩm</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body style="    background: #ffd900;">
    <h1>Đăng sản phẩm bán</h1>
    <a href="./index.php">xem tất cả sản phẩm hiện có</a>
    
    
    
    <form action="/up.php" method="post">
        <table>
            <tr>
                <th>Tên sản phẩm:</th>
                <td><input type="text" name="name_sp" value=""></td>
            </tr>

            <tr>
                <th>Ảnh xem trước: </th>
                <th>
                    <div id="container">
                        <input type="file" id="fileButton" name="">
                        <progress id="progressBar" value="0" max="100" style="width:300px;"></progress>
                        <textarea cols="30" rows="7" name="pic_sp" id="pic_sp"></textarea>
                    </div>
                </th>
                <th>
                    <div id="loaded">
                        <div id="main">
                            <div id="user-signed-in">
                                <div id="user-info">
                                    <div id="photo-container">
                                        <img id="photo" height="100px">
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </th>
            </tr>

            <!--<tr>
                <th>Tất cả ảnh (ít hơn hoặc bằng 10): </th>
                <td><input type="text" name="pics_sp" value=""></td>
            </tr>-->

            <tr>
                <th>Thông tin sản phẩm:</th>
                <td><textarea cols="30" rows="7" name="info_sp"></textarea></td>
            </tr>
            <tr>
                <th>Tất cả cỡ giày:</th>
                <td><input type="text" name="size_sp" value=""></td>
            </tr>
            <tr>
                <th>Màu sắc:</th>
                <td><input type="number" name="color_sp" value="" maxlength="1"></td>
            </tr>
            <tr>
                <th>Giá sản phẩm:</th>
                <td><input type="number" name="gia_sp" value=""></td>
            </tr>
            <tr>
                <th>Số lượng:</th>
                <td><input type="number" name="sl_sp" value=""></td>
            </tr>
            <tr>
                <th>Giới tính:</th>
                <td><input type="number" name="sex_sp" value="" maxlength="1"></td>
            </tr>
            <tr>
                <th>Loại sản phẩm:</th>
                <td><input type="number" name="type" value="" maxlength="1"></td>
            </tr>

        </table>
        <button type="submit">Gửi</button>
    </form>

    <div>
        <form action="" method="post">
            Tất cả ảnh sản phẩm ( ít hơn 10 ảnh ): <input type="text" name="txtnum"
                value="<?php echo $_POST['txtnum']; ?>" size="10" />
            <input type="submit" name="ok_num" value="Accept" />
        </form>
        <?php
if(isset($_POST['ok_num']))
{
            $num=$_POST['txtnum'];
            echo "<hr />";
            echo "Bạn chọn $num ảnh cản phẩm<br />";
            echo "<form action='doupload.php?file=$num' method='post' enctype='multipart/form-data'>";
            for($i=1; $i <= $num; $i++)
            {
                 echo "<input type='file' name='img[]' /><br />";
            }
            echo "<input type='submit' name='ok_upload' value='Upload' />";
            echo "</form>";
}
?>
    </div>





    <script type=text/javascript> </script> <script src=https://www.gstatic.com/firebasejs/6.0.4/firebase.js> </script>
        <script>
            (function () {

                console.log('connect to firebase');

                // Initialize Firebase
                var firebaseConfig = {
                    apiKey: "AIzaSyC0mgSOWba5L2hkuChXRIK3vJCH10jPX6k",
                    authDomain: "alien-proton-201406.firebaseapp.com",
                    databaseURL: "https://alien-proton-201406.firebaseio.com",
                    projectId: "alien-proton-201406",
                    storageBucket: "alien-proton-201406.appspot.com",
                    messagingSenderId: "797437083148",
                    appId: "1:797437083148:web:ca37ba117ad65edeafb829"
                };
                // Initialize Firebase
                firebase.initializeApp(firebaseConfig);
                var database = firebase.database();


                /**
                 * Initializes the app.
                 */
                var initApp = function () {

                    const fileButton = document.getElementById('fileButton');

                    if (!!fileButton) {

                        fileButton.addEventListener('change', function (e) {

                            uploadFile(e.target.files[0])

                        });
                    }


                };

                function uploadFile(file) {

                    // var newMetadata = {
                    //   cacheControl: 'public,max-age=300',
                    //   contentType: 'image/jpeg',
                    //   contentLanguage: null,
                    //   customMetadata: {
                    //     whatever: 'we feel like',
                    //   },
                    // };

                    // Create the file metadata
                    var metadata = {
                        contentType: 'image/jpeg',
                    };
                    var uploadTask = firebase.storage().ref('img/' + Date.now()).put(file, metadata);

                    // Listen for state changes, errors, and completion of the upload.
                    uploadTask.on(
                        firebase.storage.TaskEvent.STATE_CHANGED, // or 'state_changed'
                        function (snapshot) {
                            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
                            var progress = snapshot.bytesTransferred / snapshot.totalBytes * 100;
                            progressBar.value = progress;
                            console.log('Upload is ' + progress + '% done');
                            switch (snapshot.state) {
                                case firebase.storage.TaskState.PAUSED: // or 'paused'
                                    console.log('Upload is paused');
                                    break;
                                case firebase.storage.TaskState.RUNNING: // or 'running'
                                    console.log('Upload is running');
                                    break;
                            }
                        },
                        function (error) {
                            // Errors list: https://firebase.google.com/docs/storage/web/handle-errors
                            switch (error.code) {
                                case 'storage/unauthorized':
                                    // User doesn't have permission to access the object
                                    console.log('User does not have permission to access the object');
                                    break;

                                case 'storage/canceled':
                                    // User canceled the upload
                                    console.log('User canceled the upload');
                                    break;

                                case 'storage/unknown':
                                    // Unknown error occurred, inspect error.serverResponse
                                    console.log('Unknown error occurred, inspect error.serverResponse' + error.serverResponse);
                                    break;
                            }
                        },
                        function () {
                            // Upload completed successfully, now we can get the download URL

                            uploadTask.snapshot.ref.getDownloadURL().then(function (downloadURL) {
                                console.log('File available at', downloadURL);
                                if (downloadURL != null) {
                                    document.getElementById("pic_sp").value = downloadURL;
                                }
                                document.getElementById("pic_sp").readOnly = "true";
                                var _img = document.getElementById('photo');
                                var newImg = new Image;
                                newImg.onload = function () {
                                    _img.src = this.src;
                                }
                                newImg.src = downloadURL;

                            });

                        }
                    );
                }


                window.addEventListener('load', initApp);

            }())
        </script>

</body>

</html>