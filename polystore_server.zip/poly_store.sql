-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 04, 2020 lúc 12:46 PM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `poly_store`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `acc`
--

CREATE TABLE `acc` (
  `id_acc` int(11) NOT NULL,
  `user` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_date` date NOT NULL,
  `user_address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_favor` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `acc`
--

INSERT INTO `acc` (`id_acc`, `user`, `pass`, `user_name`, `user_email`, `user_date`, `user_address`, `user_favor`) VALUES
(1, 'bbs', '0331999@@@', 'Cừu Đen', '0331999bbs@gmail.com', '1999-03-30', '185 Lê Trọng Tấn,Đà Nẵng', 'null');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `id_acc` int(11) NOT NULL,
  `id_sp` int(200) NOT NULL,
  `sl_cart` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_cart` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `cart`
--

INSERT INTO `cart` (`id_cart`, `id_acc`, `id_sp`, `sl_cart`, `total_cart`) VALUES
(1, 1, 1, '1', '928000');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `feedback`
--

CREATE TABLE `feedback` (
  `id_feedback` int(11) NOT NULL,
  `id_acc` int(11) NOT NULL,
  `id_sp` int(11) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `id_acc`, `id_sp`, `content`, `rating`) VALUES
(1, 1, 1, 'Máy đẹp, mượt', 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order`
--

CREATE TABLE `order` (
  `id_order` int(11) NOT NULL,
  `id_acc` int(11) NOT NULL,
  `id_cart` int(11) NOT NULL,
  `date_order` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order`
--

INSERT INTO `order` (`id_order`, `id_acc`, `id_cart`, `date_order`) VALUES
(2, 1, 1, '2019-11-01');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sp`
--

CREATE TABLE `sp` (
  `id_sp` int(11) NOT NULL,
  `name_sp` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pic_sp` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pics_sp` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `info_sp` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_sp` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_sp` int(11) NOT NULL,
  `count_click` int(11) NOT NULL,
  `gia_sp` decimal(10,0) NOT NULL,
  `sl_sp` int(11) NOT NULL,
  `sex_sp` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `sp`
--

INSERT INTO `sp` (`id_sp`, `name_sp`, `pic_sp`, `pics_sp`, `info_sp`, `size_sp`, `color_sp`, `count_click`, `gia_sp`, `sl_sp`, `sex_sp`, `type`, `rate`) VALUES
(1, 'GIÀY MỌI NAM C.O.M060-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2Fgiay-moi-nam-c-o-m060-de_m500m500.jpg?alt=media&token=92cff3a8-921d-484c-b4ca-3741fd373689', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147921536044778.jpg?alt=media&token=ad22accb-1ec9-4c2b-9aa7-9fbfb4ef82c5,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147911536044778.jpg?alt=media&token=15e99283-5e94-40fb-a5b8-d1fe101b6b6d,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147931536044778.jpg?alt=media&token=2e526dcc-ee47-4c98-8860-38f23a115d32,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147901536133649.jpg?alt=media&token=0b0a9efa-3f30-4eb8-8b01-ef86ee9e7eab', 'Mã sản phẩm : C.O.M060-DE\r\nThương hiệu : Vũ Chầm\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 1, 52, '928000', 132, 1, 1, 5),
(2, 'GIÀY MỌI NAM ACF.H0021-XD', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2Fgiay-moi-nam-acf-h0021-xd_m500m500.jpg?alt=media&token=f45202a9-ccee-4619-a6be-f7f154aa47e0', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F128401520908763.jpg?alt=media&token=089d2dbe-3343-405b-aac1-c882cb4a335b,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F128411520908763.jpg?alt=media&token=b40317d6-c016-4952-884b-8c23014adf59,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F128421520908763.jpg?alt=media&token=2f1d1396-bbd3-4801-b9d4-f26011796487,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F128431520908763.jpg?alt=media&token=08c434e1-6d7e-4671-9bc1-e3a6f4073e17,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F128451520908763.jpg?alt=media&token=dc22c58d-dd53-43c4-9c52-6f4f583bb12a', 'Mã sản phẩm : ACF.H0021-XD\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 1, 23, '699000', 100, 1, 1, 4),
(3, 'GIÀY MỌI NAM C.O.M049-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2Fgiay-moi-nam-c-o-m049-de_m500m500.jpg?alt=media&token=c794d841-c1cd-4d38-8e5d-d95b6dbffd15', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%201.jpg?alt=media&token=ac4cca42-e41f-4c8d-8138-3ec449616245,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%202.jpg?alt=media&token=8990d479-45b8-490d-a2a3-23c97b4df907,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%203.jpg?alt=media&token=439961cf-efb4-49f0-aa89-3387d04efaf0,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%204.jpg?alt=media&token=a93ec24a-e41a-4df0-b644-2d8959fd7b04,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%205.jpg?alt=media&token=07caaff2-9a4c-4917-bfc1-b51922263637,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M049-DE%206.jpg?alt=media&token=439a66fe-acab-4a36-ab95-cd0af68ee626', 'Mã sản phẩm : C.O.M049-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 6, 30, '868000', 100, 1, 1, 5),
(4, 'GIÀY MỌI NAM C.O.M050-XD', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2Fgiay-moi-nam-c-o-m050-xd_m500m500.jpg?alt=media&token=9f2a8bfa-07bb-492f-810e-efc75406aa56', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%201.jpg?alt=media&token=c2fffc84-ce88-4a82-83cd-27d38c83b628,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%202.jpg?alt=media&token=67f3e82b-b11b-412a-a771-21c96db65ad6,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%203.jpg?alt=media&token=981985f0-39d4-4ca5-9420-cded732db34e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%204.jpg?alt=media&token=3beb4d76-f6c6-4a84-8c3e-104e9fd9a398,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%205.jpg?alt=media&token=f4451646-dcdf-4b46-acbe-007514c85c6c,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M050-XD%206.jpg?alt=media&token=75bb9f3f-059b-442c-b1a1-67c492ef0c4c', 'Mã sản phẩm : C.O.M050-XD\r\nThương hiệu : Vũ Chầm\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 6, 32, '868000', 100, 1, 1, 3),
(5, 'GIÀY BÚP BÊ NỮ C18.001-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fpreview%2Fgiay-bup-be-c18-001-vq_m500m500.jpg?alt=media&token=b91ad9f4-b010-4656-b6dc-54c0cd38a6f6', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fall_pic%2F01%20GI%C3%80Y%20B%C3%9AP%20B%C3%8A%20N%E1%BB%AE%20VINA-GI%E1%BA%A6Y%20C18.001.jpg?alt=media&token=dfe47a5b-a68b-4bb0-a5dd-f59325c3712a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fall_pic%2F2%20GI%C3%80Y%20B%C3%9AP%20B%C3%8A%20N%E1%BB%AE%20VINA-GI%E1%BA%A6Y%20C18.001.jpg?alt=media&token=82329b38-0ac0-4013-be4c-7c8aca53e343,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fall_pic%2F03%20GI%C3%80Y%20B%C3%9AP%20B%C3%8A%20N%E1%BB%AE%20VINA-GI%E1%BA%A6Y%20C18.001.jpg?alt=media&token=f4d66d3f-c5f8-4428-a5f2-da0267ef7ebf,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fall_pic%2F3GI%C3%80Y%20B%C3%9AP%20B%C3%8A%20N%E1%BB%AE%20VINA-GI%E1%BA%A6Y%20C18.001.jpg?alt=media&token=da16c911-3e0a-4119-a900-fe5dd4904fd0,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/comfort_nu%2Fall_pic%2F4%20GI%C3%80Y%20B%C3%9AP%20B%C3%8A%20N%E1%BB%AE%20VINA-GI%E1%BA%A6Y%20C18.001.jpg?alt=media&token=ca6086b4-4cef-4426-8551-ee4bfe675171', 'Mã sản phẩm : C18.001-DE\r\nThương hiệu : Giầy Việt\r\nXuất xứ : Việt Nam\r\nBảo hành : 3 Tháng', '35,36,37,38,39', 1, 22, '458000', 100, 2, 7, 4),
(9, 'GIÀY MỌI NAM C.O.M051-D3', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2Fgiay-moi-nam-c-o-m051-d3_m500m500.jpg?alt=media&token=ecfa110c-19c8-4e69-bf2e-d18fca79e2f7', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%201.jpg?alt=media&token=2a6cf3c0-b55c-4605-8ebd-bca69f26bec0,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%202.jpg?alt=media&token=e698b4c2-cbe0-4d2c-b3e5-d2010fc9a48c,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%203.jpg?alt=media&token=6c644646-2725-4c6d-86d5-80defe73abcc,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%204.jpg?alt=media&token=3126734d-ce58-4c14-80fc-9c2c101b57c8,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%205.jpg?alt=media&token=cb909dcc-522b-441c-b00b-f99bed0e30d2,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%206.jpg?alt=media&token=3f2d7fae-1f0d-43dc-8ea4-11ce61d245b1,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FC.O.M051-D3%207.jpg?alt=media&token=7dc91e59-340d-4790-906f-71aa1f46c2d1', 'Mã sản phẩm : C.O.M051-D3\r\nThương hiệu : Vũ Chầm\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 30, '928000', 123, 1, 1, 4),
(10, 'GIẦY MỌI NAM C.O.M053-D2', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2F147101535621266.jpg?alt=media&token=5dd8fd35-52f9-4769-a858-cc325eba8d40', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147141535621266.jpg?alt=media&token=f20c8067-0831-4431-a884-95608f4c5a97,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147131535621266.jpg?alt=media&token=73582453-2104-4994-81c7-709209efd289,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F147121535621266.jpg?alt=media&token=31e1b064-bed5-4a74-9d2e-53f1138672eb', 'Mã sản phẩm : C.O.M053-D2\r\nThương hiệu : Vũ Chầm\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 36, '928000', 36, 1, 1, 1),
(11, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0024-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2F118601548052920.jpg?alt=media&token=b330e019-407f-481d-932f-ebafe14d06a6', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F118631548052920.jpg?alt=media&token=2fccbedd-c3da-45f4-97c0-557e29498acf,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F118621548052920.jpg?alt=media&token=31a5bafa-5d90-4652-aa98-ea030a44660c,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F118641548052920.jpg?alt=media&token=bcb214d5-c1ab-47f9-b01c-d4a91055b8b3', 'Mã sản phẩm : AGT.H0024-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 7, 85, '989000', 45, 1, 7, 2),
(12, 'GIẦY TĂNG CHIỀU CAO AGT.H0023-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0023%201(1).jpg?alt=media&token=51b55852-caf4-438a-8ea8-08985aca6509', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%202(1).jpg?alt=media&token=a2f9bcac-6925-40df-8c28-8070bed31a36,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%204(1).jpg?alt=media&token=79eaa725-c7ed-438a-8a60-421850e235e2,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%205(1).jpg?alt=media&token=ae41c7ac-7655-419c-b999-aeb70fb2e266,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%206.jpg?alt=media&token=433f03d6-2519-4fff-984c-3d87555d13e3', 'Mã sản phẩm : AGT.H0023-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,38,40,41,42', 1, 34, '989000', 365, 1, 7, 5),
(13, 'GIẦY TĂNG CHIỀU CAO AGT.H0019-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0019-XA%201.jpg?alt=media&token=670dde04-b3b6-44e4-a2ff-472fa603c865', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-XA%203.jpg?alt=media&token=541020b4-62c0-40bb-8e99-c95d428dedb1,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-XA%206.jpg?alt=media&token=b05049fa-b1be-4e62-ae59-2ad656818ec7,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-XA%202.jpg?alt=media&token=2b2119d2-5fb3-4bba-8729-1d3da4780307,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-XA%207.jpg?alt=media&token=93c169e1-269c-4af9-b9da-cbc6fea19859', 'Mã sản phẩm : AGT.H0019-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 65, '899000', 36, 1, 7, 0),
(14, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0023-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0023%201.jpg?alt=media&token=0130b4de-ef23-4d8d-946f-442b43d82a5f', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%205.jpg?alt=media&token=c64f5d5b-3f53-4206-bd82-eb29300c393f,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%204.jpg?alt=media&token=1fa6d812-f764-4e2c-9679-98ad8bbbac21,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%203.jpg?alt=media&token=9331ab2f-9c56-4a32-91a8-8b3efb9e73ae,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0023%202.jpg?alt=media&token=3ac55583-4f10-46f9-a6e6-8f043272a75d', 'Mã sản phẩm : AGT.H0023-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 361, '789000', 25, 1, 7, 5),
(15, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0024-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0024%2011.jpg?alt=media&token=b3237bda-043d-4608-a09b-582b7156cf59', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0024%2011.jpg?alt=media&token=b3237bda-043d-4608-a09b-582b7156cf59,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0024%2012.jpg?alt=media&token=98d19cbe-c67b-4225-9b9f-720bce1231a4,\r\nhttps://console.firebase.google.com/project/datn-4ec75/storage/datn-4ec75.appspot.com/files~2Fmoi_nam~2Fall%20pic,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0024%2013.jpg?alt=media&token=542b5bfa-af6f-4898-a87b-2c08942b505a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0024%2014.jpg?alt=media&token=7fc77aad-22de-4bad-abd9-152355022b38', 'Mã sản phẩm : AGT.H0024-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 98, '480000', 36, 1, 7, 5),
(16, 'GIẦY TĂNG CHIỀU CAO AGT.H0017-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0017%201.jpg?alt=media&token=1d743992-6896-4961-ade1-3f5b21a2d89f', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0017%202.jpg?alt=media&token=d46a0635-8606-4d32-886d-8a7b99ff2928,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0017%204.jpg?alt=media&token=1d447fbd-0ae3-466f-8296-eb6dcb8735f9,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0017%205.jpg?alt=media&token=35abed82-7edd-414d-9f63-1c86c5a9d4cc,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0017%203.jpg?alt=media&token=f34b6aff-8d36-47b8-9d55-6b636437f345', 'Mã sản phẩm : AGT.H0017-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 96, '352000', 36, 1, 7, 4),
(17, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0021-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0021%208.jpg?alt=media&token=5a2633fd-b635-4b30-b604-47b458fab817', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0021%2011.jpg?alt=media&token=4eb12627-731e-497b-80c7-63d48305f3bb,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0021%208.jpg?alt=media&token=5a2633fd-b635-4b30-b604-47b458fab817,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0021%2010%20.jpg?alt=media&token=f353dbef-c459-475e-983a-065e9e6576d6,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0021%209.jpg?alt=media&token=0aef8614-ce4b-4172-925c-2521c8f287a2', 'Mã sản phẩm : AGT.H0021-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 7, 25, '625000', 85, 1, 7, 5),
(18, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0014-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0014-XA%201.jpg?alt=media&token=a38612c7-e767-4ddb-9863-7dd8811954e8', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0014-XA%204.jpg?alt=media&token=15222abd-6017-477b-9d4f-2c55364442aa,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0014-XA%207.jpg?alt=media&token=03e654c2-2ebc-4f78-8041-d878676d3c10,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0014-XA%206.jpg?alt=media&token=cfcc9efa-f8f0-4d95-83d5-aa29914ebb37', 'Mã sản phẩm : AGT.H0014-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 85, '120000', 85, 1, 7, 4),
(19, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0013-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fpreview%2FAGT.H0013-XA15.jpg?alt=media&token=228b6cd8-1835-4491-b829-15be26e573b2', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F113811512113644.jpg?alt=media&token=8f1017f9-c7f8-486f-ad13-16f54799e233,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F113821512113644.jpg?alt=media&token=88705ca5-c62b-4650-87b2-d1337d83e164,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F113841512113644.jpg?alt=media&token=8bbcc57c-e79b-42f8-9229-0dd8c8f64562,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F113831512113644.jpg?alt=media&token=e4f3be5e-661b-437f-a570-c10507460e37', 'Mã sản phẩm : AGT.H0013-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 85, '789000', 25, 1, 7, 3),
(20, 'GIẦY TĂNG CHIỀU CAO NAM AGT.H0019-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-DE%202.jpg?alt=media&token=b22f43a8-e269-4cd7-afba-d2c48c82235e', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F4(20).jpg?alt=media&token=011ce4cf-eada-43ef-a765-ec1b81f5aeec,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-DE%201.jpg?alt=media&token=8a4694a0-2546-4f9f-88ef-b1992ad36a23,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F5(16).jpg?alt=media&token=7dd0a900-107f-40a3-aea1-6f323a554ef8,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F3(19).jpg?alt=media&token=344e562d-e680-45da-903a-60a19dfb8c52,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-DE%204.jpg?alt=media&token=b9b4c4a1-5476-4f54-8a2d-635c520d81c2,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-DE%203.jpg?alt=media&token=42d158ab-ef8a-43d0-b265-9b45a7c70d17,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F6(10).jpg?alt=media&token=cf9ad701-c2ba-46d8-b610-6c831234ccf9,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2F2(26).jpg?alt=media&token=e1363c4e-62cd-4533-b52c-41cff23ce078,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/moi_nam%2Fall%20pic%2FAGT.H0019-DE%205.jpg?alt=media&token=a2fc8720-ba20-49d5-ae5c-78f6b821567f,', 'Mã sản phẩm : AGT.H0019-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Thán', '38,39,40,41,42,43', 1, 58, '250000', 35, 1, 7, 4),
(22, 'GIẦY TÂY NAM AGT.I0040 -XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=23ae0bd5-a6bc-4a08-9e78-4e3446793282', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=919426c2-4625-4a95-8773-d0fc20602b5e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=7ee1f6df-c425-45c5-81b2-ffb0017dd2e2,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F4%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=2a0ce683-9320-4d14-bf85-19fa702aaf07,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F5%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=89102630-38d4-4509-87e9-2c24066a2798,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=5cd9155f-38ed-4a16-be19-c2b603df9c09,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=5b1c14a0-3526-4921-91c0-1e76b05e2eb9', 'Mã sản phẩm : AGT.I0040 -XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 7, 85, '450000', 58, 1, 3, 5),
(23, 'GIẦY TÂY NAM 1136-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1%20GI%C3%80Y%20T%C3%82Y%20NAM%20AGT.I0040-XA.jpg?alt=media&token=23ae0bd5-a6bc-4a08-9e78-4e3446793282', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=2537b6e1-4b17-46ed-8468-a61e966cdd2a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F8%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=bd2ee676-3fe9-4835-a15d-12145534d646,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F9%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=02bc55db-2045-4c78-b0f1-3b567509cd08,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=f78ec117-f54e-4849-b8d7-650d06a93a43,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=34e6a161-24bd-4e25-a41b-356116b23244,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-XA.jpg?alt=media&token=81353a09-9b7b-43ec-8fd0-15f9829661d5', 'Mã sản phẩm : 1136-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 7, 69, '750000', 68, 1, 3, 4),
(24, 'GIẦY TÂY NAM 1210-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=1f70edd5-f18e-4dff-8fe4-018312b77638', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=3912ff3a-db07-44c6-b589-6cd0f62e7b7e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=6e30a798-2e1b-45c1-a211-2644757f4966,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F9%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=2b30b2b8-4e07-42c4-bc59-3c8966bd563d,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=4486e6a8-5ab0-4bd9-a082-525ddcc785a4,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=7fae347b-fbea-4246-a777-bd27be12554a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F8%20GI%C3%80Y%20T%C3%82Y%20NAM%201210-DE.jpg?alt=media&token=79537315-6f97-46ae-96be-e792419d3429', 'Mã sản phẩm : 1210-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ  Việt Nam\r\nBảo hành : 6 Tháng', '38,38,40,41,42,43', 1, 85, '950000', 85, 1, 3, 3),
(25, 'Giầy Tây Nam  AGT.I0040-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=4153c43c-37c9-4989-8a07-1af3343a71ac', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=60548164-e095-49a7-a6fb-199979db7927,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F4%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=7c038a13-ca59-47dd-a2e3-0aa307bb911e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=e1a0b5f2-d901-4853-b1da-537d81145ba0,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F5%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=efb65cc3-90aa-4a6a-bcc3-94d5aa00084a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=3f7a48c5-d79f-45e9-ba71-f31e84b2bc8e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2%20GI%E1%BA%A6Y%20T%C3%82Y%20NAM%20AGT.I0040-DE.jpg?alt=media&token=5a580eb8-4d5f-4f80-bd9f-ef0047a6e814', 'Mã sản phẩm : AGT.I0040-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '39,40,41,42,43', 1, 58, '850000', 68, 1, 3, 5),
(26, 'GIẦY TÂY NAM C.O.M057-DV', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1(59).jpg?alt=media&token=738d6958-617f-4a66-b42c-49516696bffb', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F5(20).jpg?alt=media&token=24cbd91f-e988-44cc-b99b-b01cb356865a,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F9(9).jpg?alt=media&token=1c82be60-9623-4294-9069-971623f6498d,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F8(12).jpg?alt=media&token=c2fe7e82-ea2e-4363-b963-b7a5eaa5029c,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F4(43).jpg?alt=media&token=c5b0b2ee-e299-4a30-a49b-daa8b2344b7e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2(51).jpg?alt=media&token=b491782a-a65f-4384-ad0b-1089c143836e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7(12).jpg?alt=media&token=3393f2ac-03cc-4167-8970-ea4da3c40945,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3(43).jpg?alt=media&token=1492eecb-0d89-4fe2-b264-4ca7829f4ede,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6(14).jpg?alt=media&token=602ae05f-7bec-46ac-b0a4-75720e1d4960', 'Mã sản phẩm : C.O.M057-DV\r\nThương hiệu : Vũ Chầm\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 25, '650100', 25, 1, 0, 5),
(27, 'GIẦY TÂY NAM AGT.H0011-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F123901517021556.jpg?alt=media&token=d759c35a-631a-45bc-870d-dfaab27b8eac', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F123911517021556.jpg?alt=media&token=135f6d9d-a69f-45a2-8b8d-55b3874cb272,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F123941517021556.jpg?alt=media&token=72d65173-079e-49b8-b8ab-3896906644c1,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F123931517021556.jpg?alt=media&token=6f5be979-593f-41d4-9884-a6b0d9853338', 'Mã sản phẩm : AGT.H0011-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 258, '456000', 100, 1, 3, 5),
(28, 'GIẦY TÂY NAM 1136-DE', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F1%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=fe6e8cac-eae7-4088-b080-29f63ccdd607', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F2%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=3aa8e067-478a-42ea-86f3-58930220a1e6,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F8%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=59f56f9c-1cc6-4d4f-be0c-ec148631b47d,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F7%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=e43c7984-a7dd-4e8a-b906-c814b21a9326,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F6%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=8be24f69-b2cd-4dec-a120-ee74d080706c,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F3%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=d9d700ba-1232-4f28-8bc9-c01364f13ca9,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F9%20GI%C3%80Y%20T%C3%82Y%20NAM%201136-DE.jpg?alt=media&token=9cbcc15d-5731-4551-b7c7-4cd00c99f0f1', 'Mã sản phẩm : 1136-DE\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42,43', 1, 25, '920000', 152, 1, 3, 5),
(29, 'GIẦY TÂY NAM AGT.H0026-XA', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpic%2F129501521097933.jpg?alt=media&token=84d1d536-e9a4-4caa-a581-ccd22ab5d14b', 'https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F129521521097933.jpg?alt=media&token=a1cc8228-6b5e-405a-ae6d-f3d0105e1c3e,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F129511521097933.jpg?alt=media&token=2b7f35ae-7c26-41c2-a85f-9bb1f0f09e63,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F129551521097933.jpg?alt=media&token=1585b164-70d7-4f60-b200-b4d5c1273a11,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F129541521097933.jpg?alt=media&token=0db3efc9-ad40-4245-a3a7-9595321b6122,https://firebasestorage.googleapis.com/v0/b/datn-4ec75.appspot.com/o/giay_tay%2Fpics%2F129531521097933.jpg?alt=media&token=a7404e2c-8078-4b57-8afb-eb9cd7935cf4', 'Mã sản phẩm : AGT.H0026-XA\r\nThương hiệu : Vina-Giầy\r\nXuất xứ : Việt Nam\r\nBảo hành : 6 Tháng', '38,39,40,41,42', 1, 25, '365000', 144, 1, 3, 4);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `acc`
--
ALTER TABLE `acc`
  ADD PRIMARY KEY (`id_acc`);

--
-- Chỉ mục cho bảng `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`),
  ADD KEY `id_sp` (`id_sp`),
  ADD KEY `id_acc` (`id_acc`);

--
-- Chỉ mục cho bảng `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id_feedback`),
  ADD KEY `id_acc` (`id_acc`),
  ADD KEY `id_sp` (`id_sp`);

--
-- Chỉ mục cho bảng `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `id_acc` (`id_acc`),
  ADD KEY `id_cart` (`id_cart`);

--
-- Chỉ mục cho bảng `sp`
--
ALTER TABLE `sp`
  ADD PRIMARY KEY (`id_sp`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id_feedback` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `order`
--
ALTER TABLE `order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `sp`
--
ALTER TABLE `sp`
  MODIFY `id_sp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`id_acc`) REFERENCES `acc` (`id_acc`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`id_sp`) REFERENCES `sp` (`id_sp`);

--
-- Các ràng buộc cho bảng `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`id_acc`) REFERENCES `acc` (`id_acc`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`id_sp`) REFERENCES `sp` (`id_sp`);

--
-- Các ràng buộc cho bảng `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`id_acc`) REFERENCES `acc` (`id_acc`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`id_cart`) REFERENCES `cart` (`id_cart`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
